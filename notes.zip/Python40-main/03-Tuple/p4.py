t1 = (10, 20, 30, 40, 50)
print(t1)
print(t1 * 2)
print(t1)

