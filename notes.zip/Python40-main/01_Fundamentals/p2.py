# number types: int, float, bool
a = 10
b = 10.0
c = True

print(a * 1)  # 10
print(b * 1)  # 10.0
print(c * 1)  # 1



