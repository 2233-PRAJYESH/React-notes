# task 1: find, rfind
# find() returns the lowest index
s = 'Hello learners like the code'
#    0123456789..................
print(s.find('l'))  # 2
print(s.find('l'))  # 2

print(s.rfind('l'))  # 15

print(s.find('l', 3, 10))  # 3

print(s.find('l', 5, 10))   # 6

print(s.find('m'))  # -1







