# constructor overloading
# what is special method /constructor
# __int__():
# special method is executed at the time object creation
class Product:

    # methods
    def __init__(self):

        print("special method")


# object (object name and class name must be same)
Product()


