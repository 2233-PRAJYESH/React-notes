from threading import Thread


# Multi-Threading

# Hello is child and Thread is Parent
# run() belongs the to Thread class
class Hello(Thread):

    def run(self):

        print("rin method")



