# oops:
# object-oriented programming
# inheritance, polymorphism, abstraction, encapsulation

# types of variables in oops
# class v, static v and instance v

# types of methods in oops
# class m, static m and instance m

# polymorphism: having many forms
# len() method is polymorphism
# + operator overloading as polymorphism

# method overloading
# constructor overloading
# method overriding

# abstraction is the process of hiding the data and high-lighting the set of services
# show room : cars: i20 car (basemodel, mid-model, top-model, top-plus-model)
# in python we use abstract keyword/decorator to make a method as abstract method
# in python to make abstract class we extend it from abc module

# encapsulation is the process of wrapping the data and their methods into as single unit




