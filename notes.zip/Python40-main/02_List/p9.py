# reverse the list
l1 = [10, 20, 30, 40, 50]
l1.reverse()
print(l1)

l1 = [10, 20, 30, 40, 50]
l1.sort(reverse=True)
print(l1)

l1 = [10, 20, 30, 40, 50]
print(l1[::-1])
