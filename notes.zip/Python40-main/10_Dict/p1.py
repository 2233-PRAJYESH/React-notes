# dict contains key value pairs
# d1 = {}
# print(d1, type(d1))
#
# d2 = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50}
# print(d2)
# print(d2.keys())
# print(d2.values())
# print(d1.items())

# Can we Assign a position to list and dict
# l1 = [10, 20, 30, 40, 50]
# #      0   1   2   3   4
# l1[5] = 60
# print(l1)

# d1 = {1: 10, 2: 20}
# d1['a'] = 'apple'
# print(d1)

