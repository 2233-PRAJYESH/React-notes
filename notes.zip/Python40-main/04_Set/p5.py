# task 5: pop()
s1 = {10, 20, 30, 40, 50}
print(s1)
s1.pop()
print(s1)
s1.pop()
print(s1)

