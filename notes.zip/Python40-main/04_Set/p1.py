# set will not main insertion order
# set will not allow duplicates
# set is mutable

s1 = {10, 20, 30, 40, 50, 10, 20}
print(s1, type(s1))

s2 = set({10, 20, 30, 40, 50})
print(s2, type(s2))

# print(dir(set))
# 'add', 'clear', 'copy', 'discard', 'pop', 'remove', 'update'
# 'difference', 'difference_update', , 'intersection', 'intersection_update', 'isdisjoint', 'issubset', 'issuperset',  'symmetric_difference', 'symmetric_difference_update', 'union',
