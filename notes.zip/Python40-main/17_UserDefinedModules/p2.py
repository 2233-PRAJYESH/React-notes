# from p1 import d1
# from p1 import d2
# from p1 import d3

from p1 import *

print(d1(5, 10))
print(d2(10, 5))
print(d3(5, 10))

