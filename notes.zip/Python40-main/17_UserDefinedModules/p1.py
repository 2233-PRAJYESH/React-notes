def d1(a, b):

    return a+b


def d2(a, b):

    return a - b


def d3(a, b):
    return a * b
