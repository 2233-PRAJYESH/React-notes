# from math import *
#
# print(factorial(5))
# print(dir())


import math

help(math)
