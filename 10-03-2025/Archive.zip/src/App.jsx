import './App.css'
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Clothing from './pages/Clothing';

function App() {

  return (
    <div>
      <Navbar/>
      {/* <Home/> */}
      <Clothing/>
      <Footer/>
    </div>
  )
}

export default App
