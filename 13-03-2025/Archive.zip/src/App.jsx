import './App.css'
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Clothes from './pages/Clothes';
import { useEffect } from 'react';
import Employees from './pages/Employees';
import Groceries from './pages/Groceries';

function App() {
  
  useEffect(() => {
    console.log('In use effect1 function...');
  }, []);

  useEffect(() => {
    console.log('In use effect2 function...');
  }, []);
  
  return (
    <div>
      <Navbar/>
      {/* <Home/> */}
      {/* <Clothes/>
      <Employees/> */}
      <Groceries/>
      <Footer/>
    </div>
  )
}

export default App
